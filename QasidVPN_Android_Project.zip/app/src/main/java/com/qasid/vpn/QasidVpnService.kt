package com.qasid.vpn

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor

class QasidVpnService : VpnService() {
    private var vpnInterface: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (vpnInterface == null) {
            vpnInterface = Builder()
                .setSession("Qasid VPN")
                .addAddress("10.8.0.2", 32)
                .addRoute("0.0.0.0", 0)
                .establish()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        vpnInterface?.close()
        vpnInterface = null
        super.onDestroy()
    }
}
