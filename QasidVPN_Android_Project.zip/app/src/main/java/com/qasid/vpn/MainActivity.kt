package com.qasid.vpn

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var button: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main)

        status = findViewById(R.id.status)
        button = findViewById(R.id.connect)

        button.setOnClickListener {
            val prepare = VpnService.prepare(this)
            if (prepare != null) {
                startActivityForResult(prepare, 100)
            } else {
                startVpn()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) startVpn()
    }

    private fun startVpn() {
        startService(Intent(this, QasidVpnService::class.java))
        status.text = "VPN service running"
        button.text = "Disconnect"
        button.setOnClickListener {
            stopService(Intent(this, QasidVpnService::class.java))
            status.text = "Disconnected"
            button.text = "Connect"
            button.setOnClickListener { startVpn() }
        }
    }
}
